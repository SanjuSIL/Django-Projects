from django.apps import AppConfig


class WebPushConfig(AppConfig):
    name = 'webpush'
    default_auto_field = 'django.db.models.AutoField'
